# -*- coding: utf-8 -*-

from . import net_profit_report
